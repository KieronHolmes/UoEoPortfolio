class StoredPaymentDetails:
    def __init__(self, method, card_no):
        """Constructs an instance of the StoredPaymentDetails class.

        Creates the required attributes for the StoredPayment Details class upon creation of the object.

        :param method: The stored Payment Method type. Can be one of the following: ['Credit Card','Debit Card']
        :param card_no: The Credit Card number to be stored.
        """
        self.method = method
        self.card_no = card_no
