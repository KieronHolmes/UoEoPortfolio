from datetime import datetime


class PromoCode:
    def __init__(self, promo_code, discount, valid_to):
        """Constructs an instance of the PromoCode class.

        Creates the required attributes when an instance of the PromoCode class is created.
        Promo Code refers to the promotional code which would have been supplied to customers.
        Discount refers to the currency value of the promotional code (x.xx format).
        Valid To refers to the expiry date of the current PromoCode instance (From this date, the code is no longer valid).

        :param promo_code: The Promotional Code.
        :param discount: The value (£) of the Promotional Code.
        :param valid_to: The expiry date of the Promotional Code (YYYY-MM-DD).
        """
        self.promo_code = promo_code
        self.promo_discount = discount
        self.promo_valid_to = valid_to

    @property
    def valid(self):
        """Determines whether the current PromoCode is valid.

        This property value returns the current validity of the PromoCode. Returns True if valid, False if invalid.
        The datetime module has been used to convert the YYYY-MM-DD format to a date/time instance for simple comparison.

        :return: True if the Promotional Code is valid. False if invalid/expired.
        """
        return datetime.now() < datetime.strptime(self.promo_valid_to, '%Y-%m-%d')

    @staticmethod
    def check_promo_code(promo_codes):
        """Checks the validity of a given Promo Code.

        This static method requests the user inputs a promotional code, then returns an instance of the PromoCode class if a valid, matching code is found within the promo_codes array parameter.

        :param promo_codes: An array containing instance of the PromoCode class.
        :return: Instance of the PromoCode class if a valid search term is entered. False if an invalid term is supplied.
        """
        user_input = input("Promo Code: ")
        for p in promo_codes:
            if p.promo_code == user_input.upper() and p.valid:
                return p
        return False
