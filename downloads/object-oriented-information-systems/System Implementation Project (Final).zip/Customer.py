import uuid
import StoredPaymentDetails
from User import User


class Customer(User):
    def __init__(self, name, email_address, password):
        """Constructs an instance of the Customer class.

        Sets the required attributes when the Object is created.
        A V4 UUID string is generated and set to the 'id' attribute, and is used for uniquely identifying a customer.
        The Name attribute refers to the customer name.
        The Email Address attribute refers to the email address of the customer.
        The password refers to a plaintext representation of the customers' password. In a production environment, this would be salted/hashed for security.
        The Stored Payment Methods array will contain instances of the StoredPaymentDetails object (Allowing multiple methods to be saved).

        :param name: The name of the customer.
        :param email_address: The email address of the customer.
        :param password: The password (plaintext) of the customer.
        """
        self.id = uuid.uuid4()
        self.name = name
        self.email_address = email_address
        self.password = password
        self.stored_payment_methods = []

    def __update_profile(self, name, email_address):
        """Updates the profile of the current customer object.

        This function provides the facility to update the name and email address of the current instance of the Customer object.
        The Name refers to the customer name.
        The Email Address attribute refers to the customer Email Address.

        :param name: The name of the customer.
        :param email_address: The email address of the customer.
        :return:
        """
        self.name = name
        self.email_address = email_address

    def store_payment_method(self, method, card_no):
        """Stores the payment method object against the current customer.

        This function provides the ability to store the specified payment method & card number against the customer object. This function directly appends an instance of the StoredPaymentDetails object to the stored_payment_methods attribute.
        Method refers to the payment method which is to be saved.
        Card Number refers to the card number which has been provided by the user.

        :param method: The payment method being saved, either 'Credit Card' or 'Debit Card'
        :param card_no: A value representing the card number
        :return:
        """
        self.stored_payment_methods.append(
            StoredPaymentDetails.StoredPaymentDetails(method, card_no))

    def request_stored_payment_method(self):
        """Determines whether to store the payment method object against the customer.

        This function displays all saved payment methods (Held in stored_payment_methods) to the user, providing the function to choose a specific payment method to use. An instance of the StoredPaymentDetails object is returned if a valid selection is made, else, False is returned.

        :return: Instance of the StoredPaymentDetails class if a valid selection is made. False if an invalid selection is made..
        """
        user_input_string = '----------\nPlease select a stored payment card:\n'
        for count, spm in enumerate(self.stored_payment_methods):
            user_input_string += (str(count) + ') ' + str(spm.card_no) + "\n")
        user_input = input(user_input_string)
        if 0 <= int(user_input) <= len(self.stored_payment_methods) - 1:
            return self.stored_payment_methods[int(user_input)]
        else:
            return False
