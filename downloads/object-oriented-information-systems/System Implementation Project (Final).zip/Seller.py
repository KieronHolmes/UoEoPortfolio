import uuid
from User import User


class Seller(User):
    def __init__(self, name, seller_type, email_address, password):
        """Constructs an instance of the Seller class.

        Lorem ipsum dolor sit amet.

        :param name: The name of the Seller.
        :param seller_type: The type of Seller. Can be one of the following: ['FIRSTPARTY','THIRDPARTY']
        :param email_address: The email address of the Seller.
        :param password: The password of the Seller.
        """
        self.id = uuid.uuid4()
        self.name = name
        self.type = seller_type
        self.email_address = email_address
        self.password = password

    def __update_seller_profile(self, name, seller_type, email_address):
        """Updates the seller profile.

        Updates the sellers details (This would be fully implemented in a production environment where multiple sellers exist).

        :param name: The name of the seller.
        :param seller_type: The type of Seller. Can be one of the following: ['FIRSTPARTY','THIRDPARTY']
        :param email_address: The email address of the Seller.
        :return:
        """
        self.name = name
        self.type = seller_type
        self.email_address = email_address
