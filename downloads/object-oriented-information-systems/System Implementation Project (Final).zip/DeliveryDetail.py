class DeliveryDetail:
    def __init__(self, name, delivery_method, delivery_address):
        """Constructs an instance of the DeliveryDetail class.

        Sets the required attributes when an instance of the DeliveryDetail class is created.
        Name refers to the Customer Name of the order recipient (Can differ from the Customer Name).
        Delivery Method refers to the method of delivery, which are Postal System (For third party orders - and first party if desired), or In-House delivery.

        :param name: The name of the customer receiving the order.
        :param delivery_method: The method of delivery, either 'IN HOUSE COURIER' or 'POSTAL SYSTEM'
        :param delivery_address: The address of the customer receiving the order.
        """
        self.name = name
        self.delivery_method = delivery_method
        self.delivery_address = delivery_address
