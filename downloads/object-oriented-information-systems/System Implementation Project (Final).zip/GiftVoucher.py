from datetime import datetime


class GiftVoucher:
    def __init__(self, code, amount, expiry):
        """Constructs an instance of the GiftVoucher class.

        Creates the required attributes when an instance of the GiftVoucher class is created.
        Code refers to the voucher code (For example, GIFTVOUCHER0192).
        Amount refers to the currency value which is held on the selected Gift Voucher.
        Expiry refers to the expiry date of the Gift Voucher. Voucher will be considered as expired when the current date is on/after this date.

        :param code: The Gift Voucher code.
        :param amount: The value (£) of the Gift Voucher.
        :param expiry: The expiry date of the Gift Voucher (YYYY-MM-DD format).
        """
        self.voucher_code = code
        self.voucher_expiry = expiry
        self.voucher_amount = amount

    @property
    def valid(self):
        """Determines whether the current GiftVoucher is valid.

        This property returns the current validity status of this GiftVoucher instance. Voucher is considered to be expired if the current date is on/after this date.
        The datetime module has been imported to handle the conversion of yyyy-mm-dd values to a python comparable string.

        :return: True if GiftVoucher is valid. False if invalid/expired.
        """
        return datetime.now() < datetime.strptime(self.voucher_expiry, '%Y-%m-%d')

    @staticmethod
    def check_gift_voucher_code(gift_voucher_codes):
        """Determines whether a Gift Voucher code supplied by the user is valid.

        This function fetches the Gift Voucher number from the user, then loops through the gift_voucher_codes array to determine if this code exists - and is valid. An instance of the GiftVoucher object is returned if existent, False if not.
        Gift_Voucher_Codes is an array containing instances of the GiftVoucher class.

        :param gift_voucher_codes: An array containing instances of the GiftVoucher class.
        :return: GiftVoucher instance if valid. False if not valid.
        """
        user_input = input("Gift Voucher: ")
        for g in gift_voucher_codes:
            if g.voucher_code == user_input.upper() and g.valid:
                return g
        return False
