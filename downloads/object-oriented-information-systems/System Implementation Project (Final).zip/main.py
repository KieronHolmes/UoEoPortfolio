from Customer import Customer
from StoredPaymentDetails import StoredPaymentDetails
from Seller import Seller
from Product import Product
from GiftVoucher import GiftVoucher
from Order import Order
from PromoCode import PromoCode
from DeliveryDetail import DeliveryDetail
from prettytable import PrettyTable
import sys


class MainMenu:
    def __init__(self):
        """Constructs an instance of the MainMenu class.

        Stored Payment Method: Two payment methods are created under the stored_method_one and stored_method_two attributes, both of these are linked to the stored_payment_methods array within the customer instance.

        Customer: A single customer instance (Named Kieron Holmes) is created, and assigned to the customer attribute.

        Seller: Two sellers (one in house, one third party) are created under the in_house_seller and external_seller attributes. Both are stored within the sellers array attribute.

        Products: Three products (Phone, Laptop, Television) are created. All three are stored within the products attribute array.

        Promo Codes: Two promo codes (10OFF/20OFF) are created. Both are stored within the promo_codes array attribute.

        Gift Voucher: Two Gift Vouchers (FIFTEENGV/TWENTYY) are created. Both are stored within the gift_vouchers array attribute.

        Order: An empty Order instance is created, stored as the order attribute.
        """
        self.stored_method_one = StoredPaymentDetails(
            'CREDIT CARD', '991999182818')
        self.stored_method_two = StoredPaymentDetails(
            'DEBIT CARD', '817281728172')
        self.customers = Customer(
            'Kieron Holmes', 'k@h.com', 'password')
        self.customers.stored_payment_methods = [
            self.stored_method_one,
            self.stored_method_two
        ]

        self.in_house_seller = Seller(
            'Online Shop Co',
            'FIRSTPARTY',
            'inhouse@abc.com',
            'password')
        self.external_seller = Seller(
            'Joe Bloggs Enterprises',
            'THIRDPARTY',
            'joe@bloggs.com',
            'password')
        self.sellers = [
            self.in_house_seller,
            self.external_seller
        ]

        self.product_phone = Product(
            'Phone', 1245, 4, 'C4', 69.99, False, self.in_house_seller)
        self.product_television = Product(
            'Television', 1243, 0, 'J6', 499.00, True, self.external_seller)
        self.product_laptop = Product(
            'Laptop', 3234, 18, 'Y17', 899, False, self.in_house_seller)
        self.products = [
            self.product_phone,
            self.product_laptop,
            self.product_television
        ]

        self.tenoff_promo = PromoCode('10OFF', 10, '2021-07-25')
        self.twentyoff_promo = PromoCode('20OFF', 20, '2021-07-25')
        self.promo_codes = [
            self.tenoff_promo,
            self.twentyoff_promo
        ]

        self.fifteen_giftvoucher = GiftVoucher(
            'FIFTEENGV', 15, '2021-07-25')
        self.twenty_giftvoucher = GiftVoucher(
            'TWENTYY', 20, '2021-07-27')
        self.gift_vouchers = [
            self.fifteen_giftvoucher,
            self.twenty_giftvoucher
        ]

        self.order = Order()

    def initial_menu(self):
        """Displays the initial menu (top-level).

        Provides the initial user interface, directing users to the seller menu, the customer menu, or the warehouse menu.

        Customer: If the user selects the Customer option, the customer_menu() function is called.

        Seller: If the user selects the Seller option, the seller_menu() function is called.

        Warehouse: If the user selects the Warehouse option, the warehouse_menu() function is called.

        :return:
        """
        while True:
            print(
                "----------\nWelcome to the 'Online Store'. Please select an option from the following: ")
            user_input = input(
                "1) Customer\n2) Seller\n3) Warehouse\n4) Exit\n>> ")
            if user_input == '1':
                self.customer_menu()
            elif user_input == '2':
                self.seller_menu()
            elif user_input == '3':
                self.warehouse_menu()
            elif user_input == '4':
                sys.exit(0)
            else:
                print("The option you have selected is not valid. Please try again...")

    def seller_menu(self):
        """Displays the seller menu.

        Provides the user interface and functionality behind the seller menu.

        View Storefront: This section uses a for loop to dynamically assign array variables, which are populated by the static search_products_by_seller() method within the Product class.

        Edit Pricing: This section uses the search_products_by_seller_id() static method within the Product class to identify whether a given value belongs to the current seller, then amends the product_price attribute of the Seller instance.

        Back: Breaks out of the While loop and returns the user to the previous menu (Initial).

        :return:
        """
        while True:
            print("----------\nPlease select an option from the following:")
            user_input = input(
                '1) View Storefront\n2) Edit Pricing\n3) Back\n>> ')
            if user_input == '1':
                print(f'Seller Detail: {self.external_seller.user_detail}')
                self.display_table(
                    ["#", "Name", "Price", "Seller", "Availability"],
                    [[p.id, p.product_name, p.product_price, p.product_seller.name, p.get_stock_level()] for p in
                     Product.search_products_by_seller(self.products, self.external_seller)])
            elif user_input == '2':
                seller_product = Product.search_products_by_seller_id(
                    self.products, self.external_seller)
                if seller_product:
                    new_price = input("New Price: ")
                    seller_product.product_price = new_price
                else:
                    print("ID Does not match seller")
            elif user_input == '3':
                break
            else:
                print("The option you have selected is not valid. Please try again...")

    def delivery_method(self):
        """Displays the Delivery Method menu.

        Provides the user interface and functionality behind the delivery method menu.

        In House Courier: Checks to see whether in-house delivery is available for this order (No third party items), then assigns an instance of the DeliveryDetail class to the delivery_details attribute (composition).

        Postal System: Assigns an instance of the DeliveryDetail class to the delivery_details attribute of the Order class.

        :return:
        """
        print("----------\nPlease supply delivery details:")
        delivery_name = input("Delivery Name: ")
        delivery_address = input("Delivery Address: ")
        while True:
            user_input = input(
                'Delivery Method: \n1) In-House Courier\n2) Postal System\n>> ')
            if user_input == '1':
                if self.order.in_house_available:
                    self.order.delivery_details = DeliveryDetail(
                        delivery_name, delivery_address, 'IN HOUSE COURIER')
                    self.payment_menu()
                else:
                    print("This shipping method is unavailable for this order")
            elif user_input == '2':
                self.order.delivery_details = DeliveryDetail(
                    delivery_name, delivery_address, 'POSTAL SYSTEM')
                self.payment_menu()
            else:
                print("The option you have selected is not valid. Please try again...")

    def customer_menu(self):
        """Displays the Customer menu.

        Provides the user interface and functionality behind the customer menu.

        View All Products: Uses the display_table function within the MainMenu class to render a table based on data in the products attribute (Uses dynamic array assignment to reformat the array for output).

        Search Products: Calls the static search_for_products() method within the Product class to identify products matching specific search criteria. These are then output using the display_table() method of the MainMenu class, with data being formatted using dynamic array assignment.

        Add Product to Cart: Calls the static search_for_product_id() method to fetch the product matching this ID (Outputs an error if not found). This is then appended to the products array of the order class using the add_item() method.

        Remove Product from Cart: Calls the static search_for_product_id() method to fetch the product matching this ID (Outputs an error if not found). This is removed from the products array of the order class using the remove_item() method.

        Checkout: Selecting the Checkout option updates the status of the Order instance to 'Processing', then refers the user to the delivery_method() method within the MainMenu class.

        :return:
        """
        while True:
            print("----------\nPlease select an option from the following:")
            user_input = input(
                '1) View All Products\n2) Search Products\n3) Add Product to Cart\n4) Remove Product from Cart\n5) Checkout\n6) Back\n>> ')
            if user_input == '1':
                self.display_table(
                    ["#", "Name", "Price", "Seller", "Availability"],
                    [[p.id, p.product_name, p.product_price, p.product_seller.name, p.get_stock_level()] for p in
                     self.products])
            elif user_input == '2':
                search_results = Product.search_for_products(self.products)
                if search_results:
                    self.display_table(
                        ["#", "Name", "Price", "Seller", "Availability"],
                        [[p.id, p.product_name, p.product_price, p.product_seller.name, p.get_stock_level()] for p in
                         search_results])
                else:
                    print("No results found")
            elif user_input == '3':
                search_product = Product.search_for_product_id(self.products)
                if search_product:
                    self.order.add_item(search_product)
                    print(f'{search_product.product_name} added to basket')
                else:
                    print("No results found for supplied ID")
            elif user_input == '4':
                search_product = Product.search_for_product_id(self.products)
                if search_product:
                    self.order.remove_item(search_product)
                    print(f'{search_product.product_name} removed from basket')
                else:
                    print("No results found for supplied ID")
            elif user_input == '5':
                self.order.order_status = 'PROCESSING'
                self.delivery_method()
                pass
            elif user_input == '6':
                break
            else:
                print("The option you have selected is not valid. Please try again...")

    def warehouse_menu(self):
        """Displays the warehouse menu.

        Provides the user interface and functionality behind the warehouse menu.

        View Orders/Locations: Displays the Order ID (Order class), Order Status (Order class) and information about the user (Customer class, inherited from User). The ordered items are then output using the display_table() method in the MainMenu class.

        Scan Item: Uses the search_for_product_id() static method within the Product class. The user is then required to enter the new stock level, which is applied to the product_stock_level attribute of the Product class.

        Check Shipping Method & Mark as Shipped: This function displays various pieces of information relating to the order, including shipping method and delievry information.

        :return:
        """
        while True:
            print("----------\nPlease select an option from the following:")
            user_input = input(
                '1) View Orders/Locations\n2) Scan Item\n3) Check Shipping Method & Mark Order as Shipped\n4) Back\n>> ')
            if user_input == '1':
                print(
                    f'Order #: {str(self.order.id)} ({self.order.order_status})\nUser Detail: {self.customers.user_detail}')
                self.display_table(["#",
                                    "Name",
                                    "Price",
                                    "Seller",
                                    "Availability",
                                    "Location"],
                                   [[p.id, p.product_name, p.product_price, p.product_seller.name, p.get_stock_level(),
                                     p.product_warehouse_location] for p in self.order.products])
            elif user_input == '2':
                search_product = Product.search_for_product_id(self.products)
                if search_product:
                    new_stock_level = input("New Stock Level: ")
                    self.order.add_item(search_product)
                    search_product.product_stock_level = int(new_stock_level)
                    print(f'Stock updated to {str(new_stock_level)}')
                else:
                    print("No results found for supplied ID")
            elif user_input == '3':
                if self.order.checkout_completed:
                    self.order.order_status = 'SHIPPED'
                    print(f'Shipping Method: {self.order.delivery_details.delivery_method}\nDelivery Name: {self.order.delivery_details.name}\nDelivery Address: {self.order.delivery_details.delivery_address}\nOrder #{str(self.order.id)} was marked as shipped!')
                else:
                    print("Order status is not awaiting picking")
            elif user_input == '4':
                break
            else:
                print("The option you have selected is not valid. Please try again...")

    def payment_menu(self):
        """Displays the Payment menu.

        Provides the user interface and functionality behind the payment menu.

        Credit Card: When the credit card option is selected, the user is prompted to enter their credit card number. The store_payment_method() function within the MainMenu class is called.

        Debit Card: When the debit card option is selected, the user is prompted to enter their debit card number. The store_payment_method() function within the MainMenu class is called.

        Promo Code: The check_promo_code() static method within the PromoCode class is executed, fetching user input and identifying whether this is a valid promo code. If valid, the apply_promo() method within the Order class is called.

        Stored Payment Method: The request_stored_payment_method() method from the Customer class is called, which provides a list of the active methods linked to the customer account. Once complete, the user is directed to the end of the checkout process.

        Gift Voucher: The check_gift_voucher_code() static method within the GiftVoucher class is executed, fetching user input and identifying whether this is a valid promo code. If valid, the apply_voucher() method within the Order class is called.

        :return:
        """
        self.order.order_status = 'PENDING PAYMENT'
        while True:
            print("----------\nOrder Total: " + str(
                self.order.total) + "\nPlease select your payment method from the following:")
            user_input = input(
                '1) Credit Card\n2) Debit Card\n3) Promo Code\n4) Stored Payment Method\n5) Gift Voucher\n>> ')
            if user_input == '1':
                user_input = input('Credit Card Number: ')
                self.store_payment_method('CREDIT CARD', user_input)
            elif user_input == '2':
                user_input = input('Debit Card Number: ')
                self.store_payment_method('DEBIT CARD', user_input)
            elif user_input == '3':
                promo_code_output = PromoCode.check_promo_code(
                    self.promo_codes)
                if not promo_code_output:
                    print("Promo Code Invalid/Expired")
                else:
                    self.order.apply_promo(promo_code_output)
                    print("Code Applied")
            elif user_input == '4':
                spm = self.customers.request_stored_payment_method()
                if not spm:
                    print("Stored Payment Method Invalid")
                else:
                    self.order_complete()
            elif user_input == '5':
                gift_voucher_output = GiftVoucher.check_gift_voucher_code(
                    self.gift_vouchers)
                if not gift_voucher_output:
                    print("Gift Voucher Invalid/Expired")
                else:
                    self.order.apply_voucher(gift_voucher_output)
                    print("Voucher Applied")
            else:
                print("The option you have selected is not valid. Please try again...")

    def store_payment_method(self, method, card_input):
        """Displays the Store Payment Method menu.

        Provides the user interface and functionality behind the store payment method menu.

        Yes: The store_payment_method() method within the Customer class is called. The order is then marked as complete and the summary displayed.

        No: The order_complete() method is called, and the order is marked as complete.

        :param method: Payment Method to store. Can be one of the following: ['Credit Card','Debit Card'].
        :param card_input: The card number.
        :return:
        """
        while True:
            print("----------\nWould you like to store this payment method?")
            user_input = input('1) Yes\n2) No\n>> ')
            if user_input == '1':
                self.customers.store_payment_method(method, card_input)
                self.order_complete()
            elif user_input == '2':
                self.order_complete()
            else:
                print("The option you have selected is not valid. Please try again...")

    def order_complete(self):
        """Displays the Order Complete summary.

        Function to mark the current order as complete, as well as displaying a complete summary including the products, ID and order status.

        :return:
        """
        self.order.order_status = 'AWAITING PICKING'
        print("-----\nThank you for your order, a summary has been included below for your reference:")
        print(f'Order #: {str(self.order.id)} ({self.order.order_status})')
        self.display_table(["#",
                            "Name",
                            "Price",
                            "Seller",
                            "Availability",
                            "Location"],
                           [[p.id, p.product_name, p.product_price, p.product_seller.name, p.get_stock_level(),
                             p.product_warehouse_location] for p in self.order.products])
        print(f'Order Total: {str(self.order.total)}')
        self.initial_menu()

    @staticmethod
    def display_table(columns, data):
        """Displays data in a tabular format.

        Uses PrettyTable module to display given data/columns in a tabular format.

        :param columns: An array containing the column names.
        :param data: An array containing the data to be displayed.
        :return:
        """
        table = PrettyTable()
        table.field_names = columns
        for d in data:
            table.add_row(d)
        print(table)


if __name__ == '__main__':
    try:
        MainMenu().initial_menu()
    except KeyboardInterrupt:
        pass
