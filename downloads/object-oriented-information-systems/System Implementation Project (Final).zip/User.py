class User:
    def _process_login(self, email, password):
        """Processes log in for a given user.

        Handles the login process for a user (Inherited by Seller/Customer). This function is not implemented, but would be within a production environment where > 1 seller/customer exist.

        :param email: The email address of the user.
        :param password: The password of the user.
        :return: True if email address and password are correct. False if incorrect.
        """
        return email == self.email_address and password == self.password

    def _reset_password(self, old_password, new_password):
        """Resets the password of the current user.

        Resets the password for a user (Inherited by Seller/Customer). This function is not implemented, but would be within a production environment where > 1 seller/customer exists.

        :param old_password: The current password for the user.
        :param new_password: The users desired new password.
        :return: True if old passwords match. False if they do not.
        """
        if old_password is self.password:
            self.password = new_password
            return True
        else:
            return False

    @property
    def user_detail(self):
        """Returns the name and email address of the current user.

        Inherited property to return the name of the current user, as well as the email address (For display on order summary screens).

        :return: The users name and email address.
        """
        return self.name + ' ('+self.email_address+')'
