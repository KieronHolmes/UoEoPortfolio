import uuid


class Product:
    def __init__(
            self,
            product_name,
            product_ean,
            product_stock_level,
            product_warehouse_location,
            product_price,
            third_party_seller,
            product_seller):
        """Constructs an instance of the Product class.

        Sets the values of all required attributes when an instance of the Product class is created.
        Product_Name refers to the name of the product.
        Product_EAN refers to the barcode value of the product (This would be used in a production environment instead of the ID within the warehouse menu).
        Product Stock Level is the numerical value representing the number of items in stock.
        Warehouse Location refers to the location of this item within the warehouse.
        Product Price refers to the total cost of the product (£x.xx)
        Third Party Seller is a boolean value representing whether this is an in-house or third-party product.
        Product Seller is an instance of the Seller class, representing the seller of this specific product instance.

        :param product_name:
        :param product_ean:
        :param product_stock_level:
        :param product_warehouse_location:
        :param product_price:
        :param third_party_seller:
        :param product_seller:
        """
        self.id = uuid.uuid4()
        self.product_name = product_name
        self.product_ean = product_ean
        self._product_stock_level = product_stock_level
        self.product_warehouse_location = product_warehouse_location
        self._product_price = product_price
        self.third_party_seller = third_party_seller
        self.product_seller = product_seller

    @property
    def product_price(self):
        """Returns the price of the current Product.

        Encapsulated property to return the price of the current product object.

        :return: Price of the product in format x.xx
        """
        return self._product_price

    @product_price.setter
    def product_price(self, value):
        """Sets the price of the current Product.

        Setter function to set the value of the current product.

        :param value: The price of the product.
        :return:
        """
        self._product_price = value

    @property
    def product_stock_level(self):
        """Returns the stock level of the current Product.

        Encapsulated property to return the current stock level (numeric).

        :return:
        """
        return self._product_stock_level

    @product_stock_level.setter
    def product_stock_level(self, value):
        """Sets the stock level of the current Product.

        Setter function to set the numerical value of the current product object.

        :param value: The value to set as the current stock level.
        :return:
        """
        self._product_stock_level = value

    def get_stock_level(self):
        """Returns the stock level of the current product as a textual representation.

        Returns a textual representation of the current product objects stock level, with options returned being On Backorder (<0), Unavailable (=0) and In Stock (>0).

        :return: A textual representation of the current stock level. Can be one of ['In Stock','Unavailable','On Backorder'].
        """
        if self.product_stock_level > 0:
            return 'In Stock'
        elif self.product_stock_level == 0:
            return 'Unavailable'
        elif self.product_stock_level < 0:
            return 'On Backorder'

    @staticmethod
    def search_for_product_id(products):
        """Searches for products matching a given ID.

        Requests a Product ID from the user. Returns an instance of the product class in the event that this ID is contained within the products array (passed as a parmeter).

        :param products: An array containing instances of the Product class.
        :return: An instance of the Product class (If supplied ID matches a valid product). False if none are found.
        """
        user_input = input("Product #: ")
        products = [p for p in products if user_input == str(p.id)]
        if len(products) == 1:
            return products[0]
        return False

    @staticmethod
    def search_for_products(products):
        """Searches for products containing a given term.

        Requests a search term from the user. Returns an array containing instances of the product class in the event that the term matches product(s).

        :param products: An array containing instances of the Product class.
        :return: An array containing instances of the Product class (If supplied search term matches products). False if none are found.
        """
        user_input = input("Search Term: ")
        products = [p for p in products if user_input.lower()
                    in p.product_name.lower()]
        if len(products) > 0:
            return products
        return False

    @staticmethod
    def search_products_by_seller(products, seller):
        """Returns products sold by a specific seller.

        Returns an array consisting of instances of the Product class, where the product_seller attribute is equal to the seller parameter passed to the function.

        :param products: An array containing instances of the Product class.
        :param seller: An instance of the Seller class.
        :return: An array containing instances of the Product class (If seller matches). False if none are found.
        """
        products = [p for p in products if p.product_seller is seller]
        if len(products) > 0:
            return products
        return False

    @staticmethod
    def search_products_by_seller_id(products, seller):
        """Searches for products sold by a specific seller.

        Requests a product ID from the user. Returns an instance of the Product ID if it exists within the products parameter, and the seller matches the product_seller attribute of the product.

        :param products: An array containing instances of the Product class.
        :param seller: An instance of the Seller class.
        :return: An instance of the Product class (If ID matches an item sold by specified seller). False if none are found.
        """
        user_input = input("Product #: ")
        products = [
            p for p in products if p.product_seller is seller and str(
                p.id) == user_input.lower()]
        if len(products) == 1:
            return products[0]
        return False
