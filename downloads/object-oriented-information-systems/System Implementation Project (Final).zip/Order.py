import uuid


class Order:
    def __init__(self):
        """Constructs an instance of the Order class.

        Creates the required attributes when an instance of the Order class is created.
        A V4 UUID is used to provide a unique identifier for the current order.
        The order status is set by default to 'In Progress', suggesting the order is in a pre-checkout (and modifiable) state.
        The Products attribute contains instances of the Product class. This refers to products which are either in the cart/order (Depending on status)
        The Promo Codes attribute contains instances of the PromoCode class. This refers to promotional codes which have been applied to the order in the checkout process.
        The Gift Vouchers attribute contains instances of the GiftVoucher class. This refers to gift vouchers which have been applied to the order in the checkout process.
        """
        self.id = uuid.uuid4()
        self._order_status = 'IN PROGRESS'
        self.products = []
        self.promo_codes = []
        self.gift_vouchers = []

    def apply_promo(self, promo):
        """Applies an instance of the PromoCode class to the current order.

        This function takes an instance of the PromoCode object, and appends it to the promo_codes attribute of the current Order instance.

        :param promo: An instance of the PromoCode class.
        :return:
        """
        self.promo_codes.append(promo)

    def apply_voucher(self, voucher):
        """Applies an instance of the GiftVoucher class to the current order.

        This function takes an instance of the GiftVoucher object, and appends it to the gift_vouchers attribute of the current Order instance.

        :param voucher: An instance of the GiftVoucher class.
        :return:
        """
        self.gift_vouchers.append(voucher)

    @property
    def total(self):
        """Returns the total cost of the order.

        This property returns the total cost of the order (Minus the value of applied Gift Vouchers ana Promo Codes).

        :return: Total cost of the order (Minus Gift Voucher & Promo Codes).
        """
        cumalative_sum = 0.00
        for product in self.products:
            cumalative_sum += product.product_price
        for voucher in self.gift_vouchers:
            cumalative_sum -= voucher.voucher_amount
        for promo in self.promo_codes:
            cumalative_sum -= promo.promo_discount
        return round(cumalative_sum, 2)

    @property
    def order_status(self):
        """Returns the current status of the order.

        This property provides an encapsulated method of accessing the current status of the order.

        :return: The status of the current order.
        """
        return self._order_status

    @order_status.setter
    def order_status(self, value):
        """Sets the current status of the order.

        This setter function updates the current order status to the given value contained in the 'value' parameter.

        :param value: The Order Status to be updated to. Can be one of ['IN PROGRESS','PROCESSING','AWAITING PAYMENT','AWAITING PICKING','SHIPPED']
        :return:
        """
        self._order_status = value.upper()

    @property
    def in_house_available(self):
        """Determines whether in-house delivery is available for the order.

        This function determines whether the current order is eligible for in-house delivery. This is done by looping through the product attribute, returning False if a Third Party order is identified.

        :return: True if there are no third party items in the order. False if the order contains third party items.
        """
        for product in self.products:
            if product.third_party_seller:
                return False
        return True

    @property
    def can_be_amended(self):
        """Determines whether the current order can be amended.

        This function determines whether the customer is able to amend this order instance. Only "In Progress" orders can be amended through the Customer interface.

        :return: True if the order status is IN PROGRESS, False if it is set to anything else.
        """
        if self.order_status == 'IN PROGRESS':
            return True
        return False

    @property
    def checkout_completed(self):
        """Determines whether the current order has completed the checkout process.

        This function determines whether the checkout process has been completed, allowing the warehouse staff to scan/mark as shipped. An order is considered to be "completed" from the customer perspective if it is "Awaiting Shipping" or "Shipped".

        :return: True if the order status is 'AWAITING PICKING' or 'SHIPPED', False if it is set to anything else.
        """
        if self.order_status == 'AWAITING PICKING' or self.order_status == 'SHIPPED':
            return True
        return False

    def add_item(self, product):
        """Adds an instance of the Product class to the current order.

        Appends an instance of the Product object to the products attribute of the current order instance.

        :param product: An instance of the Product class.
        :return:
        """
        self.products.append(product)

    def remove_item(self, product):
        """Removes an instance of the Product class from the current order.

        Attempts to remove an instance of the product object from the products attribute of the current order instance. Catching ValueError and passing to prevent errors in the event that the current item is not in the products list.

        :param product: An instance of the Product class.
        :return:
        """
        try:
            self.products.remove(product)
        except ValueError:
            pass
